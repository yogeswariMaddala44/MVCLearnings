﻿using LiskovExampleSolidPrinc;

class LiskoveExample
{
    public static void Main(String[] args)
    { 
        IFruits fruits = new Apple();
        Console.WriteLine($"Apple Color is:{fruits.GetColor()}");
         fruits = new Orange();
        Console.WriteLine($"Orange Color is:{fruits.GetColor()}");
    }
} 
