﻿namespace LiskovExampleSolidPrinc
{
    public class Apple: IFruits
    { 
       public string GetColor()
        {
            return "Red";
        }
    }
}
