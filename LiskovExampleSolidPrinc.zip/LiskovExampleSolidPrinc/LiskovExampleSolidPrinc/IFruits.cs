﻿namespace LiskovExampleSolidPrinc
{
    public interface IFruits
    {
        String GetColor();
    }
}
