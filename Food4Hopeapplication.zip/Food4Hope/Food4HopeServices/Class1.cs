﻿namespace Food4HopeServices
{
    public class Class1
    {

    }
}