﻿namespace Food4HopeRepository.IRepository
{
    public interface IUnitOfWork<T> where T : class
    {
		TRepository CreateRepositoryInstance<TRepository>() where TRepository : class;

		Task SaveAsync();
	}
}
