﻿using Food4HopeBuisinessObjects.Models;

namespace Food4HopeRepository.IRepository
{
    public interface IDonarsRepository
    {
        string InsertDonorDetails(DonarsDetails donarsDetails);
    }
}
