﻿
using Food4HopeBuisinessObjects.DTO_s;
using Food4HopeBuisinessObjects.Models;

namespace Food4HopeRepository.IRepository
{
	public interface IVolunteerRepository
	{
		Task<string> InsertVolunteerDetails(VolunteerDetails volunteerDetails);

		Task<bool> IsVolunteerExist(VolunteerLogDTO volunteerLogDetails);

	}
}
