﻿using Food4HopeBuisinessObjects.Context;
using Food4HopeBuisinessObjects.Models;
using Food4HopeRepository.IRepository;


namespace Food4HopeRepository.Repository
{
	public class DonarsRepository : IDonarsRepository
	{  
        private readonly Food4HopeContext _dbContext;
        public DonarsRepository(Food4HopeContext dbContext) {   

            _dbContext = dbContext; 
        }

		public string InsertDonorDetails(DonarsDetails donarsDetails)
		{
			try
			{   
				_dbContext.DonarsDetails!.Add(donarsDetails);
				
			} 
			catch (Exception)
			{
			
			}
			return "Success";
		}
	}
}
