﻿using Food4HopeBuisinessObjects.Context;
using Food4HopeRepository.IRepository;

namespace Food4HopeRepository.Repository
{
	public class UnitOfWork<T> : IUnitOfWork<T> where T : class
	{   
        private readonly Food4HopeContext _dbContext;

		private readonly Dictionary<Type, object> _repositories = new();

		public UnitOfWork(Food4HopeContext dbContext) {  
            _dbContext = dbContext; 
        }

		public TRepository CreateRepositoryInstance<TRepository>() where TRepository : class
		{ 
			var repositoryType = typeof(TRepository);
			if (!_repositories.ContainsKey(repositoryType))
			{
				_repositories[repositoryType] = Activator.CreateInstance(repositoryType, _dbContext)!;
			}
			return (TRepository)_repositories[repositoryType];
		}

		public async Task SaveAsync()
        {
             await _dbContext.SaveChangesAsync();
        }
    }  
}
