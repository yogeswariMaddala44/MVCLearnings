﻿using Food4HopeBuisinessObjects.Context;
using Food4HopeBuisinessObjects.DTO_s;
using Food4HopeBuisinessObjects.Models;
using Food4HopeRepository.IRepository;
using Microsoft.EntityFrameworkCore;


namespace Food4HopeRepository.Repository
{
	public class VolunteerRepository : IVolunteerRepository
	{
		private readonly Food4HopeContext _dbContext;
		public VolunteerRepository(Food4HopeContext dbContext) {  

			_dbContext = dbContext; 
		}

		public async Task<string> InsertVolunteerDetails(VolunteerDetails volunteerDetails)
		{
			try
			{
				await _dbContext.VolunteerDetails!.AddAsync(volunteerDetails);

			}
			catch (Exception)
			{

			}
			return "Success";
		}

		public async Task<bool> IsVolunteerExist(VolunteerLogDTO volunteerLogDetails)
		{
			return await _dbContext.VolunteerDetails!.AnyAsync(x => x.Email == volunteerLogDetails.LogInId || x.PhoneNumber == volunteerLogDetails.LogInId && x.Password == volunteerLogDetails.Password);
		}
	}
}
