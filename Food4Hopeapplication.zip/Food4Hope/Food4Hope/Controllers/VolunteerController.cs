﻿using AspNetCore;
using Food4HopeBuisinessObjects.DTO_s;
using Food4HopeBuisinessObjects.Models;
using Food4HopeRepository.IRepository;
using Food4HopeRepository.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Food4Hope.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VolunteerController : ControllerBase
    {

		private  readonly IUnitOfWork<IVolunteerRepository> _unitOfWork;

		public VolunteerController(IUnitOfWork<IVolunteerRepository> unitOfWork)
		{
			this._unitOfWork = unitOfWork;

		}

		[HttpPost("GetDetails")]
		public async Task<string> GetDetails(VolunteerDetails volunteerDetails)
		{

			var result = await _unitOfWork.CreateRepositoryInstance<VolunteerRepository>().InsertVolunteerDetails(volunteerDetails);
			if (result != null)
			{
				await _unitOfWork.SaveAsync();
			}
			return result!;
		}

		[HttpPost("GetLogInDetails")] 
		public async Task<bool> GetLogInDetails(VolunteerLogDTO volunteerLogDetails)
		{
			var result = await _unitOfWork.CreateRepositoryInstance<VolunteerRepository>().IsVolunteerExist(volunteerLogDetails);
			return result!;

		}

	} 
}
