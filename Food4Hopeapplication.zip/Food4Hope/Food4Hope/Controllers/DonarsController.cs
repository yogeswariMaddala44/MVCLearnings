﻿using Food4HopeBuisinessObjects.Models;
using Food4HopeRepository.IRepository;
using Food4HopeRepository.Repository;
using Microsoft.AspNetCore.Mvc;

namespace Food4Hope.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DonarsController : ControllerBase
    {
        private readonly IUnitOfWork<IDonarsRepository> _unitOfWork;    

        public DonarsController(IUnitOfWork<IDonarsRepository> unitOfWork) 
        {
            this._unitOfWork = unitOfWork; 

        }  

        [HttpPost("GetDetails")] 
        public string GetDetails(DonarsDetails donarsDetails)
        {

           var result = _unitOfWork.CreateRepositoryInstance<DonarsRepository>().InsertDonorDetails(donarsDetails);
            if (result != null)
            {
                _unitOfWork.SaveAsync();
            }
            return result!;
		}

    }
}
