using Food4HopeBuisinessObjects.Context;
using Food4HopeRepository.IRepository;
using Food4HopeRepository.Repository;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
string connection = builder.Configuration.GetConnectionString("defaultConnection");
// Add services to the container.
builder.Services.AddControllersWithViews(); 

builder.Services.AddSwaggerGen();

builder.Services.AddTransient(typeof(IUnitOfWork<>), typeof(UnitOfWork<>));

builder.Services.AddTransient<DonarsRepository>(); 
builder.Services.AddTransient<VolunteerRepository>();

builder.Services.AddDbContext<Food4HopeContext>(options =>
{
    options.UseSqlServer(connection);
});


var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.UseSwagger();
app.UseSwaggerUI(); 

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
