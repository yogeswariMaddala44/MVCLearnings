﻿namespace Food4HopeBuisinessObjects.DTO_s
{
	public class VolunteerLogDTO
	{ 
		public string LogInId { get; set; } = string.Empty; 

		public string Password { get; set; } = string.Empty;
	}
}
