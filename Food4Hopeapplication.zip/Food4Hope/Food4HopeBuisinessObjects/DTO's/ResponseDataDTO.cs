﻿
namespace Food4HopeBuisinessObjects.DTO
{
	public class ResponseDataDTO
	{
		public string Data { get; set; } = string.Empty; 

		public string ErrorMesage { get; set; } = string.Empty;  

		public bool Status { get; set; }
	}
}
