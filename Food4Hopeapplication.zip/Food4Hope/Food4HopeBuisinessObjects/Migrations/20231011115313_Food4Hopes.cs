﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Food4HopeBuisinessObjects.Migrations
{
    public partial class Food4Hopes : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "DeliuveredDateTime",
                table: "VolunteerDetails",
                newName: "DeliveredDateTime");

            migrationBuilder.AddColumn<string>(
                name: "Password",
                table: "VolunteerDetails",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Password",
                table: "VolunteerDetails");

            migrationBuilder.RenameColumn(
                name: "DeliveredDateTime",
                table: "VolunteerDetails",
                newName: "DeliuveredDateTime");
        }
    }
}
