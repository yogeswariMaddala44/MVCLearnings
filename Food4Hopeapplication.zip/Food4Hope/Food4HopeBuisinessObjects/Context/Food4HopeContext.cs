﻿using Food4HopeBuisinessObjects.Models;
using Microsoft.EntityFrameworkCore;


namespace Food4HopeBuisinessObjects.Context
{
    public class Food4HopeContext : DbContext
    {
        public Food4HopeContext(DbContextOptions options) : base(options)
        {
        } 

        public DbSet<DonarsDetails>? DonarsDetails {  get; set; } 
        
        public DbSet<VolunteerDetails>? VolunteerDetails { get; set; }
    }
}
