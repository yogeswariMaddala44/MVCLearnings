﻿

using System.ComponentModel.DataAnnotations;

namespace Food4HopeBuisinessObjects.Models
{
    public class DonarsDetails
    {
        [Key]
        public int DonarsId { get; set; }   
        
        public string FirstName { get; set; } = string.Empty;  
        
        public string MiddleName {  get; set; } = string.Empty; 

        public string LastName { get; set; } = string.Empty; 

        public string PhoneNumber { get; set; } = string.Empty;  

        public string QuantityOfFood {  get; set; } = string.Empty;

        public string Email { get; set; } = string.Empty;

        public string Location { get; set; } = string.Empty; 

        public DateTime DateTime { get; set; } 

        public bool FoodStatus { get; set; } 


    }
}
